
from django.views import generic
from .models import Director, Pelicula



# Create your views here.

class IndexView(generic.ListView):
    template_name = 'peliculas/directores.html'
    model = Director

class DirectorView(generic.DeleteView):
    template_name = 'películas/director.html'
    model = Director

class PeliculaView(generic.DeleteView):
    template_name = 'peliculas/peliculas.html'
    model = Pelicula
